Hello Proffesure Earl! This is here to let you know that the data I used for this project was organized by me. I didnt like the data sets I could choose from so I made one that intrested me.

The following consist of convention data gathered by the event organizers or patrons
AC data comes from https://www.anthrocon.org/history
BLFC data comes from https://en.wikifur.com/wiki/Biggest_Little_Fur_Con
EF data comes from https://archive.eurofurence.org/
FC data comes from https://en.wikifur.com/wiki/Further_Confusion
FF data comes from https://en.wikifur.com/wiki/Furry_Fiesta
FWA data comes from https://www.furryweekend.com/about/history/
MFF data comes from https://www.furfest.org/charity/history
MP data comes from https://archives.megaplexcon.org/